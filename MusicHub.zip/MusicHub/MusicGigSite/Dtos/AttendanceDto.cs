﻿namespace GigHub.Dtos
{
    public class AttendanceDto
    {
        public int GigId { get; set; }    
    }
}